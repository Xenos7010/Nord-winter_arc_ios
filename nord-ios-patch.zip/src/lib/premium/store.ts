import { toast } from "sonner";
import { create } from "zustand";
import { PRODUCT_ID, PRICE_FALLBACK } from "./constants";
import { billing, isNativeStore, storeLabels, verifyOnServer } from "./billing";

/**
 * Le statut Premium n'est JAMAIS enregistré sur l'appareil : il est relu auprès de
 * la boutique (Google Play / App Store) à chaque lancement et à chaque retour dans l'app (les remboursements
 * sont donc pris en compte). Aucune valeur locale modifiable ne peut le débloquer.
 */
export type PremiumStatus = "checking" | "free" | "premium" | "unavailable";
export type UnavailableReason = "web" | "store";

type State = {
  status: PremiumStatus;
  reason: UnavailableReason | null;
  pending: boolean;
  price: string;
  busy: boolean;
  /** Dernier événement de cette session : achat effectué ou achat restauré. */
  event: "purchased" | "restored" | null;
  refresh: () => Promise<PremiumStatus>;
  buy: () => Promise<void>;
  restore: () => Promise<void>;
};

const offline = () => `Impossible de joindre ${storeLabels().to.replace("à ", "")}. Vérifie ta connexion puis réessaie.`;

async function readEntitlement(): Promise<{ status: PremiumStatus; pending: boolean }> {
  const e = await billing.getEntitlement();
  if (e.billing !== "ok") return { status: "unavailable", pending: false };
  if (!e.premium) return { status: "free", pending: e.pending };
  if (e.purchaseToken) {
    const verified = await verifyOnServer(e.purchaseToken, PRODUCT_ID);
    if (verified === false) return { status: "free", pending: false };
  }
  return { status: "premium", pending: false };
}

export const usePremiumStore = create<State>()((set, get) => ({
  status: "checking",
  reason: null,
  pending: false,
  price: PRICE_FALLBACK,
  busy: false,
  event: null,

  refresh: async () => {
    if (!isNativeStore()) {
      set({ status: "unavailable", reason: "web" });
      return "unavailable";
    }
    try {
      const { status, pending } = await readEntitlement();
      set({ status, pending, reason: status === "unavailable" ? "store" : null });
      if (status !== "unavailable") {
        billing
          .getProduct()
          .then((p) => p.available && p.price && set({ price: p.price }))
          .catch(() => undefined);
      }
      return status;
    } catch {
      set({ status: "unavailable", reason: "store" });
      return "unavailable";
    }
  },

  buy: async () => {
    if (get().busy) return;
    if (!isNativeStore()) {
      toast("NORD Premium s'achète depuis l'application mobile (Android ou iPhone).");
      return;
    }
    set({ busy: true });
    try {
      const r = await billing.purchase();
      if (r.status === "cancelled") {
        toast("Achat annulé.");
      } else if (r.status === "pending") {
        set({ pending: true });
        toast(`Paiement en attente. Premium s'activera dès que ${storeLabels().at.replace("chez ", "")} l'aura validé.`);
      } else if (r.status === "unavailable") {
        toast(r.message ?? offline());
      } else if (r.status === "error") {
        toast(r.message ?? "Le paiement n'a pas abouti. Aucun montant n'a été débité.");
      } else {
        const status = await get().refresh();
        if (status === "premium") {
          set({ event: r.status === "already_owned" ? "restored" : "purchased" });
          toast(r.status === "already_owned" ? "Achat retrouvé. NORD Premium est actif." : "Merci. NORD Premium est actif.");
        } else {
          toast("Achat reçu, vérification en cours. Réessaie dans un instant.");
        }
      }
    } catch {
      toast(offline());
    } finally {
      set({ busy: false });
    }
  },

  restore: async () => {
    if (get().busy) return;
    if (!isNativeStore()) {
      toast("La restauration se fait depuis l'application mobile (Android ou iPhone).");
      return;
    }
    set({ busy: true });
    try {
      // iOS : synchronise avec l'App Store (peut demander l'identifiant Apple). Android : relecture simple.
      await billing.restore().catch(() => undefined);
      const status = await get().refresh();
      if (status === "premium") {
        set({ event: "restored" });
        toast("Achat restauré. NORD Premium est actif.");
      } else if (status === "unavailable") {
        toast(offline());
      } else {
        toast(get().pending ? `Un paiement est encore en attente ${storeLabels().at}.` : `Aucun achat à restaurer pour ce ${storeLabels().account}.`);
      }
    } finally {
      set({ busy: false });
    }
  },
}));

export const useIsPremium = () => usePremiumStore((s) => s.status === "premium");
