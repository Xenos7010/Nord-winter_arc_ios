import { Capacitor, registerPlugin } from "@capacitor/core";

export type Entitlement = {
  premium: boolean;
  pending: boolean;
  /** "ok" : boutique joignable. "unavailable" : boutique absente, hors ligne ou service indisponible. */
  billing: "ok" | "unavailable" | "error";
  /** Android uniquement (vérification serveur Google Play facultative). */
  purchaseToken?: string;
  orderId?: string;
  message?: string;
};

export type PurchaseResult = {
  status: "purchased" | "pending" | "cancelled" | "already_owned" | "unavailable" | "error";
  message?: string;
};

export type ProductInfo = { available: boolean; price?: string; message?: string };

interface NordBillingPlugin {
  getEntitlement(): Promise<Entitlement>;
  getProduct(): Promise<ProductInfo>;
  purchase(): Promise<PurchaseResult>;
  /** iOS uniquement : AppStore.sync() puis relecture du statut. */
  restore(): Promise<Entitlement>;
}

const Native = registerPlugin<NordBillingPlugin>("NordBilling");

export type StorePlatform = "android" | "ios" | "web";

export const storePlatform = (): StorePlatform => {
  const p = Capacitor.getPlatform();
  return p === "android" || p === "ios" ? p : "web";
};

export const isAndroidNative = () => storePlatform() === "android";
export const isIosNative = () => storePlatform() === "ios";
/** Application installée depuis une boutique (Google Play ou App Store). */
export const isNativeStore = () => storePlatform() !== "web";

/** Formulations adaptées à la boutique de la plateforme courante. */
export const storeLabels = () =>
  isIosNative()
    ? {
        to: "à l'App Store",
        by: "par l'App Store",
        at: "chez Apple",
        account: "identifiant Apple",
        kept: "ton identifiant Apple",
      }
    : {
        to: "à Google Play",
        by: "par Google Play",
        at: "chez Google Play",
        account: "compte Google Play",
        kept: "ton compte Google Play",
      };

export const billing = {
  getEntitlement: () => Native.getEntitlement(),
  getProduct: () => Native.getProduct(),
  purchase: () => Native.purchase(),
  /** Android : le compte Google Play fait foi, relire suffit. iOS : synchronisation avec l'App Store. */
  restore: () => (isIosNative() ? Native.restore() : Native.getEntitlement()),
};

/**
 * Vérification serveur facultative, Android / Google Play uniquement
 * (VITE_VERIFY_URL → /api/verify-purchase). Sur iOS, StoreKit 2 vérifie déjà
 * cryptographiquement chaque transaction sur l'appareil : aucun jeton n'est renvoyé.
 * Réponse valide → Premium confirmé. Réponse invalide → refusé. Serveur injoignable → on garde le résultat de la boutique.
 */
export async function verifyOnServer(token: string, productId: string): Promise<boolean | null> {
  const url = import.meta.env.VITE_VERIFY_URL as string | undefined;
  if (!url) return null;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ purchaseToken: token, productId }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { valid?: boolean };
    return data.valid === true;
  } catch {
    return null;
  }
}
