# Ajoute les fichiers Swift au projet Xcode généré par Capacitor et règle signature / versions.
require 'xcodeproj'

project = Xcodeproj::Project.open('ios/App/App.xcodeproj')
target = project.targets.find { |t| t.name == 'App' } or abort('Cible "App" introuvable')
group = project.main_group['App'] or abort('Groupe "App" introuvable')

%w[NordBillingPlugin.swift NordViewController.swift].each do |name|
  next if target.source_build_phase.files_references.any? { |r| r && r.path == name }
  ref = group.files.find { |r| r.path == name } || group.new_file(name)
  target.add_file_references([ref])
end

team  = ENV['APPLE_TEAM_ID'].to_s
build = ENV['BUILD_NUMBER'].to_s
ver   = ENV['MARKETING_VERSION'].to_s

target.build_configurations.each do |c|
  s = c.build_settings
  s['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0' # StoreKit 2
  unless team.empty?
    s['DEVELOPMENT_TEAM'] = team
    s['CODE_SIGN_STYLE'] = 'Automatic'
  end
  s['CURRENT_PROJECT_VERSION'] = build unless build.empty?
  s['MARKETING_VERSION'] = ver unless ver.empty?
end
project.build_configurations.each { |c| c.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0' }

project.save
puts 'Projet Xcode configuré.'
