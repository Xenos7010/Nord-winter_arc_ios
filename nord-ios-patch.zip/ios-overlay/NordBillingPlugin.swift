import Foundation
import Capacitor
import StoreKit

/// Pont StoreKit 2 : même contrat JS que le plugin Android (getEntitlement / getProduct / purchase),
/// plus `restore` (obligatoire côté App Store). Aucun statut n'est stocké : tout est relu auprès d'Apple.
@objc(NordBillingPlugin)
public class NordBillingPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "NordBillingPlugin"
    public let jsName = "NordBilling"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "getEntitlement", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getProduct", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "purchase", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "restore", returnType: CAPPluginReturnPromise),
    ]

    private let productId = "nord_premium"
    private var updatesTask: Task<Void, Never>?

    public override func load() {
        // Achats approuvés plus tard (Ask to Buy), remboursements, achats faits hors de l'app :
        // on clôt la transaction, le JS relit le statut au retour dans l'app.
        updatesTask = Task.detached {
            for await update in Transaction.updates {
                if case .verified(let tx) = update { await tx.finish() }
            }
        }
    }

    deinit { updatesTask?.cancel() }

    // MARK: - Helpers

    private func currentEntitlement() async -> (premium: Bool, orderId: String?) {
        for await result in Transaction.currentEntitlements {
            if case .verified(let tx) = result, tx.productID == productId, tx.revocationDate == nil {
                return (true, String(tx.id))
            }
        }
        return (false, nil)
    }

    private func entitlementPayload() async -> [String: Any] {
        let e = await currentEntitlement()
        var out: [String: Any] = ["premium": e.premium, "pending": false, "billing": "ok"]
        if let id = e.orderId { out["orderId"] = id }
        return out
    }

    private func resolveStatus(_ call: CAPPluginCall, _ status: String, _ message: String? = nil) {
        var out: [String: Any] = ["status": status]
        if let message = message { out["message"] = message }
        call.resolve(out)
    }

    // MARK: - Méthodes JS

    @objc func getEntitlement(_ call: CAPPluginCall) {
        Task { call.resolve(await entitlementPayload()) }
    }

    @objc func restore(_ call: CAPPluginCall) {
        Task {
            // Peut demander l'identifiant Apple ; une annulation ou un échec réseau n'est pas bloquant.
            do { try await AppStore.sync() } catch {}
            call.resolve(await entitlementPayload())
        }
    }

    @objc func getProduct(_ call: CAPPluginCall) {
        Task {
            do {
                let products = try await Product.products(for: [productId])
                if let p = products.first {
                    call.resolve(["available": true, "price": p.displayPrice])
                } else {
                    call.resolve(["available": false, "message": "Produit introuvable dans l'App Store."])
                }
            } catch {
                call.resolve(["available": false, "message": error.localizedDescription])
            }
        }
    }

    @objc func purchase(_ call: CAPPluginCall) {
        Task {
            do {
                if await currentEntitlement().premium {
                    resolveStatus(call, "already_owned")
                    return
                }
                guard AppStore.canMakePayments else {
                    resolveStatus(call, "unavailable", "Les achats sont désactivés sur cet appareil.")
                    return
                }
                let products = try await Product.products(for: [productId])
                guard let product = products.first else {
                    resolveStatus(call, "unavailable", "Produit introuvable dans l'App Store.")
                    return
                }
                let result = try await product.purchase()
                switch result {
                case .success(let verification):
                    switch verification {
                    case .verified(let tx):
                        await tx.finish()
                        resolveStatus(call, "purchased")
                    case .unverified:
                        resolveStatus(call, "error", "Achat non vérifié par Apple. Aucun montant n'a été débité.")
                    }
                case .userCancelled:
                    resolveStatus(call, "cancelled")
                case .pending:
                    resolveStatus(call, "pending")
                @unknown default:
                    resolveStatus(call, "error")
                }
            } catch {
                if let e = error as? StoreKitError, case .networkError = e {
                    resolveStatus(call, "unavailable")
                } else {
                    resolveStatus(call, "error", error.localizedDescription)
                }
            }
        }
    }
}
