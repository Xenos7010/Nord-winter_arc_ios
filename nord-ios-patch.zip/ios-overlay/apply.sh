#!/usr/bin/env bash
# Ajoute le pont StoreKit au projet iOS généré par Capacitor.
# À lancer depuis la racine, après `npx cap add ios` (macOS uniquement).
set -euo pipefail
APP="ios/App/App"
[ -d "$APP" ] || { echo "ios/ introuvable : lance d'abord npx cap add ios"; exit 1; }

cp ios-overlay/NordBillingPlugin.swift ios-overlay/NordViewController.swift "$APP/"

# Le storyboard charge notre contrôleur (qui enregistre le plugin) au lieu de celui de Capacitor.
STORYBOARD="$APP/Base.lproj/Main.storyboard"
perl -pi -e 's/customClass="CAPBridgeViewController" customModule="Capacitor"/customClass="NordViewController" customModule="App"/' "$STORYBOARD"
grep -q 'NordViewController' "$STORYBOARD" || { echo "Storyboard non modifié : format inattendu"; exit 1; }

# Évite la question « chiffrement » à chaque envoi sur TestFlight.
PLIST="$APP/Info.plist"
/usr/libexec/PlistBuddy -c "Add :ITSAppUsesNonExemptEncryption bool false" "$PLIST" 2>/dev/null \
  || /usr/libexec/PlistBuddy -c "Set :ITSAppUsesNonExemptEncryption false" "$PLIST"

perl -pi -e "s/platform :ios, '1[0-4]\.0'/platform :ios, '15.0'/" ios/App/Podfile

ruby -e "require 'xcodeproj'" 2>/dev/null || sudo gem install xcodeproj --no-document
ruby ios-overlay/configure-xcodeproj.rb
echo "Overlay iOS appliqué."
