import UIKit
import Capacitor

/// Contrôleur principal : enregistre le plugin de facturation (plugin local à l'app).
class NordViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(NordBillingPlugin())
    }
}
