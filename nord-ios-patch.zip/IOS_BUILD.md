# NORD — build iOS (.ipa) via GitHub Actions

Le projet iOS n'est pas stocké dans le dépôt : il est généré à chaque build (Capacitor + `ios-overlay/`).
Achat Premium : StoreKit 2 (produit `nord_premium`, achat unique 1,99 €), même interface JS que sur Android.

## Deux workflows (onglet Actions)
| Workflow | Compte Apple payant | Résultat |
|---|---|---|
| **Build iOS (IPA signé + TestFlight)** | oui (99 $/an) | `.ipa` signé + envoi TestFlight, Premium fonctionnel |
| **Build iOS (IPA non signé…)** | non | `.ipa` à installer avec Sideloadly/AltStore (7 jours), Premium indisponible |

## Côté Apple (une seule fois)
1. S'inscrire à l'**Apple Developer Program**.
2. developer.apple.com → *Certificates, IDs & Profiles* → **Identifiers** → + → App ID → Bundle ID **explicite** `com.nord.arc90`.
3. Même endroit → **Devices** → enregistrer **au moins un iPhone** (UDID). Obligatoire : la signature automatique en a besoin pour l'archive.
4. **App Store Connect** → Accords : accepter le contrat *Apps payantes* et renseigner banque + fiscalité (sinon les achats intégrés ne marchent pas).
5. App Store Connect → Apps → **+ Nouvelle app** : nom NORD, Bundle ID `com.nord.arc90`, langue Français.
6. L'app → *Monétisation* → **Achats intégrés** → + **Non consommable** : ID produit `nord_premium`, prix 1,99 €, nom/description en français, capture d'écran de revue.
7. *Utilisateurs et accès* → *Intégrations* → **API App Store Connect** → générer une clé (rôle **Admin**), télécharger le `.p8` (une seule fois), noter **Key ID** et **Issuer ID**.
8. Noter le **Team ID** (developer.apple.com → Compte → Appartenance).

## Côté GitHub
1. Copier le contenu de ce paquet dans le dépôt (en gardant les chemins), commit.
2. *Settings → Secrets and variables → Actions → New repository secret* :
   - `APPLE_TEAM_ID` : Team ID
   - `APPSTORE_KEY_ID` : Key ID
   - `APPSTORE_ISSUER_ID` : Issuer ID
   - `APPSTORE_API_KEY` : contenu complet du `.p8` (lignes BEGIN/END comprises)
3. *Actions → Build iOS (IPA signé + TestFlight) → Run workflow* (15–25 min).
4. Le `.ipa` est en bas de la page du run (artefact `NORD-ipa`). Le build arrive dans App Store Connect → **TestFlight** après traitement (10–30 min) : ajouter ton Apple ID en testeur interne, installer via l'app TestFlight.

Un `.ipa` « app-store-connect » ne s'installe pas directement sur un iPhone : on passe par TestFlight.

## Tester l'achat
Via TestFlight, les achats sont en bac à sable (aucun débit réel). Restaurer : onglet Toi → « Restaurer mes achats ».

## Si le build échoue
- *no devices / cannot generate provisioning profile* → enregistrer un iPhone (étape 3).
- *Cloud signing permission / not authorized* → la clé API doit avoir le rôle **Admin**.
- *No profiles for com.nord.arc90* → créer le Bundle ID (étape 2) et l'app dans App Store Connect (étape 5).
- Numéro de build déjà utilisé → relancer (il est dérivé de l'heure).

## À savoir
- Icône : celle de Capacitor par défaut. Fournis une icône 1024×1024 (`@capacitor/assets`) avant la soumission App Store.
- `verify-purchase.post.ts` reste réservé à Google Play ; sur iOS, StoreKit 2 vérifie déjà chaque transaction sur l'appareil.
- Apple exige Xcode 26+ pour tout envoi (runner `macos-26`).

## Build local (Mac)
```bash
npm ci && npm install --no-save @capacitor/ios@7
MOBILE_BUILD=1 node scripts/with-app-env.mjs vite build
node scripts/ios-setup.mjs
npx cap open ios   # puis Product → Archive
```
