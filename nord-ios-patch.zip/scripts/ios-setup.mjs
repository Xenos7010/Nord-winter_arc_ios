#!/usr/bin/env node
// Prépare le projet iOS : cap add ios (si absent) → overlay StoreKit → cap sync.
// Pré-requis : macOS, Xcode, CocoaPods, @capacitor/ios installé, et le build web déjà fait (dist/client).
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";

function run(command, args) {
  console.log(`\n$ ${command} ${args.join(" ")}`);
  const result = spawnSync(command, args, { stdio: "inherit", shell: false });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

if (process.platform !== "darwin") {
  console.error("Le projet iOS ne peut être préparé que sur macOS.");
  process.exit(1);
}
if (!existsSync("node_modules/@capacitor/ios")) {
  console.error("@capacitor/ios est absent. Lance : npm install --no-save @capacitor/ios@7");
  process.exit(1);
}
if (!existsSync("dist/client")) {
  console.error("dist/client est absent. Lance d'abord : MOBILE_BUILD=1 node scripts/with-app-env.mjs vite build");
  process.exit(1);
}

if (!existsSync("ios")) run("npx", ["cap", "add", "ios"]);
run("bash", ["ios-overlay/apply.sh"]);
run("npx", ["cap", "sync", "ios"]);
console.log("\nProjet iOS prêt.");
